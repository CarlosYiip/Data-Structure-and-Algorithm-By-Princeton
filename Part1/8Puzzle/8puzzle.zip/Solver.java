//import edu.princeton.cs.algs4.In;
//import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;
//import java.util.Comparator;

public class Solver {
//    private final static Comparator<Node> BY_MANHATTAN = new ByManhattan();    
    private int minimumMoves;
    private Stack<Board> path = new Stack<Board>();
    private MinPQ<Node> pq = new MinPQ<Node>();
    private boolean solvable;
    
//    private static class ByManhattan implements Comparator<Node> {
//        public int compare(Node a, Node b) {
//            return a.getBoard().manhattan() - 
//                b.getBoard().manhattan();
//        }
//    }
    
    private class Node implements Comparable<Node> {
        private Board searchNodeBoard;
        private int movesToReach;
        private Node previous;
        private boolean isTwin;
                    
        public Node(Board b, int m, Node p, boolean isTwin) {
            searchNodeBoard = b;
            movesToReach = m;
            previous = p;
            this.isTwin = isTwin;
        }
        
        public Board getBoard() {
            return searchNodeBoard;
        }
        
        public int getPriority() {
            return movesToReach + searchNodeBoard.manhattan();
        }
        
        public Node getPrevious() {
            return previous;
        }
        
        public int getMoves() {
            return movesToReach;
        }
        
        public int compareTo(Node that) {
            return this.getPriority() - that.getPriority();
        }
        
        public boolean isTwin() {
            return isTwin;
        }
    }
    
    public Solver(Board initial) {
        Node root = new Node(initial, 0, null, false);
        pq.insert(root);
        
        Node twin = new Node(initial.twin(), 0, null, true);
        pq.insert(twin);
        
        int count = 0;
        while (true) {
            if (pq.isEmpty()) {
                solvable = false;
                return;
            }
            
            Node currentNode = pq.delMin();
//            if (!pq.isEmpty()) {
//                if (pq.min().getPriority() == currentNode.getPriority()) {
//                    MinPQ<Node> pqByManhattan = new MinPQ<Node>(BY_MANHATTAN);
//                    pqByManhattan.insert(currentNode);
//                    while (pq.min().getPriority() == currentNode.getPriority()) {
//                        Node nextNodeWithSamePriority = pq.delMin();
//                        pqByManhattan.insert(nextNodeWithSamePriority);
//                        if (pq.isEmpty()) break;
//                    }
//                    currentNode = pqByManhattan.delMin();
//                    while(!pqByManhattan.isEmpty()) {
//                        pq.insert(pqByManhattan.delMin());
//                    }
//                }
//            }
//            StdOut.println(currentNode.getBoard());
                        
            Board currentBoard = currentNode.getBoard();
            if (currentBoard.isGoal()) {
                if (currentNode.isTwin()) {
                    minimumMoves = -1;
                    path = null;
                    solvable = false;
                    return;
                }                
                minimumMoves = currentNode.getMoves();
                path.push(currentBoard);
                while (currentNode.getPrevious() != null) {
                    Node previousNode = currentNode.getPrevious();
                    path.push(previousNode.getBoard());
                    currentNode = previousNode;
                }
                solvable = true;
                break;                
            }
            
            for (Board neighbor : currentBoard.neighbors()) {
                Node previousNode = currentNode.getPrevious();
                int nextMove = currentNode.getMoves() + 1;                
                if (previousNode == null) {
                    Node childNode = new Node(neighbor, nextMove, currentNode, 
                                              currentNode.isTwin());
                    pq.insert(childNode);
                    continue;
                }
                Board previousBoard = previousNode.getBoard();
                if (!neighbor.equals(previousBoard)) {
                    Node childNode = new Node(neighbor, nextMove, currentNode, 
                                              currentNode.isTwin());
                    pq.insert(childNode);
                }
            }
            count++;            
        }                
    }
    
    public boolean isSolvable() {
        return solvable;
    }
    
    public int moves() {
        return minimumMoves;
    }
    
    public Iterable<Board> solution() {          
        return path;
    }
    
//    public static void main(String[] args) {
//        // for each command-line argument
//        for (String filename : args) {
//            // read in the board specified in the filename
//            In in = new In(filename);
//            int n = in.readInt();
//            int[][] tiles = new int[n][n];
//            for (int i = 0; i < n; i++) {
//                for (int j = 0; j < n; j++) {
//                    tiles[i][j] = in.readInt();
//                }
//            }
//            // solve the slider puzzle
//            Board initial = new Board(tiles);
//            Solver solver = new Solver(initial);
//            if (solver.isSolvable()) {
//                StdOut.println("Minimum number of moves = "
//                                   + solver.moves());            
//                for (Board b: solver.solution()) {
//                    StdOut.println(b);
//                }
//            } else {
//                StdOut.println("Unsolvable!");
//            }
//        }
//    }
}